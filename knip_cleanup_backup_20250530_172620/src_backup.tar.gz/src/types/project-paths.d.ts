/**
 * Module path aliases for TypeScript
 */

declare module "@/*" {
  const value: any;
  export default value;
}
