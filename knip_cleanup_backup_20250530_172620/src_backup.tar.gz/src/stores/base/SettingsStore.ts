import { defineStore } from 'pinia';
import { BaseStore } from './BaseStore';

interface SettingsState {
  theme: string;
  language: string;
  notifications: boolean;
  autoSave: boolean;
}

export const useSettingsStore = defineStore('settings', {
  state: (): SettingsState => ({
    theme: 'light',
    language: 'en',
    notifications: true,
    autoSave: true
  }),

  getters: {
    currentTheme: (state) => state.theme,
    currentLanguage: (state) => state.language,
    notificationsEnabled: (state) => state.notifications,
    autoSaveEnabled: (state) => state.autoSave
  },

  actions: {
    setTheme(theme: string) {
      this.theme = theme;
    },

    setLanguage(language: string) {
      this.language = language;
    },

    toggleNotifications() {
      this.notifications = !this.notifications;
    },

    toggleAutoSave() {
      this.autoSave = !this.autoSave;
    },

    updateSettings(settings: Partial<SettingsState>) {
      Object.assign(this, settings);
    }
  }
});