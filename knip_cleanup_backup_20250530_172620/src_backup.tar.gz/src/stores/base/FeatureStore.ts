import { defineStore } from 'pinia';
import { BaseStore } from './BaseStore';

interface Feature {
  id: string;
  name: string;
  enabled: boolean;
  description?: string;
  metadata?: Record<string, any>;
}

interface FeatureState {
  features: Feature[];
  loading: boolean;
}

export const useFeatureStore = defineStore('features', {
  state: (): FeatureState => ({
    features: [],
    loading: false
  }),

  getters: {
    allFeatures: (state) => state.features,
    enabledFeatures: (state) => state.features.filter(f => f.enabled),
    isFeatureEnabled: (state) => (featureId: string) => {
      const feature = state.features.find(f => f.id === featureId);
      return feature?.enabled ?? false;
    },
    featureById: (state) => (id: string) => state.features.find(f => f.id === id)
  },

  actions: {
    setFeatures(features: Feature[]) {
      this.features = features;
    },

    toggleFeature(featureId: string) {
      const feature = this.features.find(f => f.id === featureId);
      if (feature) {
        feature.enabled = !feature.enabled;
      }
    },

    enableFeature(featureId: string) {
      const feature = this.features.find(f => f.id === featureId);
      if (feature) {
        feature.enabled = true;
      }
    },

    disableFeature(featureId: string) {
      const feature = this.features.find(f => f.id === featureId);
      if (feature) {
        feature.enabled = false;
      }
    },

    setLoading(loading: boolean) {
      this.loading = loading;
    }
  }
});