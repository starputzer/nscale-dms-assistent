import { defineStore } from 'pinia';
import { BaseStore } from './BaseStore';

interface Resource {
  id: string;
  name: string;
  type: string;
  url?: string;
  metadata?: Record<string, any>;
}

interface ResourceState {
  resources: Resource[];
  loading: boolean;
  error: string | null;
}

export const useResourceStore = defineStore('resources', {
  state: (): ResourceState => ({
    resources: [],
    loading: false,
    error: null
  }),

  getters: {
    allResources: (state) => state.resources,
    resourceById: (state) => (id: string) => state.resources.find(r => r.id === id),
    resourcesByType: (state) => (type: string) => state.resources.filter(r => r.type === type),
    isLoading: (state) => state.loading,
    hasError: (state) => !!state.error
  },

  actions: {
    addResource(resource: Resource) {
      this.resources.push(resource);
    },

    updateResource(id: string, updates: Partial<Resource>) {
      const index = this.resources.findIndex(r => r.id === id);
      if (index !== -1) {
        this.resources[index] = { ...this.resources[index], ...updates };
      }
    },

    removeResource(id: string) {
      this.resources = this.resources.filter(r => r.id !== id);
    },

    setLoading(loading: boolean) {
      this.loading = loading;
    },

    setError(error: string | null) {
      this.error = error;
    },

    clearResources() {
      this.resources = [];
    }
  }
});