// Diese Datei dient nur zum Test von Typ-Importen
import AppPure from "./App.pure.vue";

// Wenn dieser Import ohne Fehler funktioniert, sind die Typen in App.pure.vue in Ordnung
const app = AppPure;

export default app;
