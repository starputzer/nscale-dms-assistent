#!/bin/bash
# Start the server
cd /opt/nscale-assist/app/api
python server.py